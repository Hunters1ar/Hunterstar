import readline from 'readline';

export async function startAiChat() {
    console.log('\x1b[35m🤖 Hunterstar AI CLI Initialized.\x1b[0m');
    console.log('Type \x1b[31m"exit"\x1b[0m to quit, or \x1b[33m"clear"\x1b[0m to reset conversation.\n');
    
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    let messages = [];

    const ask = () => {
        rl.question('\x1b[36mYou:\x1b[0m ', async (input) => {
            const trimmed = input.trim();
            if (trimmed.toLowerCase() === 'exit') {
                console.log('\x1b[35mGoodbye! 👋\x1b[0m');
                rl.close();
                return;
            }
            if (trimmed.toLowerCase() === 'clear') {
                messages = [];
                console.clear();
                console.log('\x1b[32mConversation cleared.\x1b[0m\n');
                return ask();
            }
            if (!trimmed) return ask();

            messages.push({ role: 'user', content: trimmed });
            process.stdout.write('\x1b[33mAI is thinking...\x1b[0m');

            try {
                // Connecting to the backend API you already built!
                const apiUrl = process.env.HUNTERSTAR_API_URL || 'https://api.hunterstar.uz/api/chat';
                
                const response = await fetch(apiUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ messages })
                });
                
                const data = await response.json();
                
                // Clear the "thinking..." line
                process.stdout.write('\r\x1b[K'); 
                
                if (response.ok && data.ok) {
                    const aiMsg = data.data.choices[0].message.content;
                    console.log(`\n\x1b[35mHunterstar AI:\x1b[0m\n${aiMsg}\n`);
                    messages.push({ role: 'assistant', content: aiMsg });
                } else {
                    console.log(`\n\x1b[31mError:\x1b[0m ${data.error || 'Unknown error'}\n`);
                    messages.pop(); // Remove the user message if it failed
                }
            } catch (err) {
                process.stdout.write('\r\x1b[K');
                console.log(`\n\x1b[31mConnection Error:\x1b[0m Could not reach the API.\nDetails: ${err.message}\n`);
                messages.pop(); // Remove the user message if it failed
            }
            ask();
        });
    };
    
    ask();
}
