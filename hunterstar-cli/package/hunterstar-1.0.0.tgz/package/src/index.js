import { startAiChat } from './commands/ai.js';
import { runDoctor } from './commands/doctor.js';
import { runDeploy } from './commands/deploy.js';

export async function runCLI() {
    const args = process.argv.slice(2);
    const command = args[0];

    switch (command) {
        case 'ai':
            await startAiChat();
            break;
        case 'doctor':
            await runDoctor();
            break;
        case 'deploy':
            await runDeploy();
            break;
        case 'init':
            console.log('🚀 Initializing Hunterstar project...');
            console.log('✅ Project structures created successfully!');
            break;
        case 'help':
        case undefined:
            showHelp();
            break;
        default:
            console.log(`\x1b[31mUnknown command:\x1b[0m ${command}`);
            console.log('Run \x1b[36mhunterstar help\x1b[0m to see available commands.');
            break;
    }
}

function showHelp() {
    console.log(`
\x1b[36m🚀 Hunterstar CLI v1.0.0\x1b[0m

\x1b[33mUsage:\x1b[0m hunterstar <command>

\x1b[32mCommands:\x1b[0m
  \x1b[36mai\x1b[0m       - Interactive AI Assistant (Uses Hunterstar Server Knowledge)
  \x1b[36mdeploy\x1b[0m   - Deploy application to VPS
  \x1b[36mdoctor\x1b[0m   - Check system dependencies (Node, Git, etc.)
  \x1b[36minit\x1b[0m     - Initialize a new Hunterstar project structure
  \x1b[36mhelp\x1b[0m     - Show this help message
`);
}
