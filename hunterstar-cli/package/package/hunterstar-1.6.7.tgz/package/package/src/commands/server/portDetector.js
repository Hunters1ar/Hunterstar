export class PortDetector {
    constructor() {
        this.detectedPorts = new Map(); // Map process name to port
        this.portResolvers = new Map(); // Map process name to promise resolvers
    }

    feedLog(name, logLine) {

        const portMatch = logLine.match(/(?:http:\/\/(?:localhost|127\.0\.0\.1|0\.0\.0\.0):|port\s+|listening\s+on\s+port\s+)(\d{4,5})/i);
        if (portMatch) {
            const port = parseInt(portMatch[1], 10);
            this.detectedPorts.set(name, port);
            
            if (this.portResolvers.has(name)) {
                const resolve = this.portResolvers.get(name);
                this.portResolvers.delete(name);
                resolve(port);
            }
        }
    }

    waitForPort(name, timeoutMs = 10000) {
        return new Promise((resolve) => {
            if (this.detectedPorts.has(name)) {
                return resolve(this.detectedPorts.get(name));
            }

            this.portResolvers.set(name, resolve);

            setTimeout(() => {
                if (this.portResolvers.has(name)) {
                    this.portResolvers.delete(name);
                    resolve(null);
                }
            }, timeoutMs);
        });
    }

}
